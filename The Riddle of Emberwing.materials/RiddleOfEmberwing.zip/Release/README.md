# Instructions

1. Install WindowsGlulxe_061_153.exe
2. Open "The Riddle of Emberwing - Prolo.gblorb"
